import os
from dotenv import load_dotenv
from planner_agent import PlannerAgent
from enrichment_spacex import SpaceXAgent
from enrichment_weather import WeatherAgent
from enrichment_summarizer import SummarizerAgent
from pathlib import Path

load_dotenv(dotenv_path=Path(__file__).resolve().parent / ".env.example")
print("SPACEX_API_URL:", os.getenv("SPACEX_API_URL"))
def load_agents():
    return {
        "spacex": SpaceXAgent(),
        "weather": WeatherAgent(),
        "summarizer": SummarizerAgent(),
    }

def main(goal):
    # Verify environment variables are loaded
    api_url = os.getenv("SPACEX_API_URL")
    weather_key = os.getenv("OPENWEATHER_API_KEY")
    
    if not api_url:
        raise ValueError("SPACEX_API_URL not found in environment variables")
    if not weather_key:
        raise ValueError("OPENWEATHER_API_KEY not found in environment variables")

    planner = PlannerAgent()
    plan = planner.plan(goal)
    context = {
        "api_url": api_url,
        "weather_key": weather_key
    }
    
    agents = load_agents()
    for step in plan:
        agent_name = step["agent"]
        agent = agents[agent_name]
        try:
            output = agent.run(context)
            context.update(output)
        except Exception as e:
            print(f"Error running {agent_name} agent:", str(e))
            return

    
    print(context.get("summary", ""), 
    "Status:", context.get("status", ""))

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--goal", required=True)
    args = parser.parse_args()
    main(args.goal)